<!-- pagination -->
<div class="pagination">
	<?php majestic_pagination(); ?>
</div>
<!-- /pagination -->
