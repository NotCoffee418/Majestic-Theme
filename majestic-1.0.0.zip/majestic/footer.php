				<!-- /container content -->
				</div>
			</div>

			<!-- footer -->
			<footer class="footer container" role="contentinfo">

				<!-- copyright -->
				<p class="copyright">
					&copy; <?php echo date('Y'); ?> Copyright <?php bloginfo('name'); ?>. <?php _e('Powered by', 'majestic'); ?>
					<a href="//wordpress.org" title="WordPress">WordPress</a> &amp; <a href="https://github.com/rstijn" title="Majestic Theme">Majestic</a>.
				</p>
				<!-- /copyright -->

			</footer>
			<!-- /footer -->

		</div>
		<!-- /wrapper -->

		<?php wp_footer(); ?>

	</body>
</html>
